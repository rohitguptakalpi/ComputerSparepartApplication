package com.java.exceptions;

public class SparepartNotFoundException extends Exception {

	public SparepartNotFoundException(String message) {
		super(message);
		
	}

	
}
